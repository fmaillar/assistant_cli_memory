# Profil Stratégique – Florian

(Données consolidées – 12 dimensions…)