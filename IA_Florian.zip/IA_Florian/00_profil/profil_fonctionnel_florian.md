
<!-- 🟡 Contenu fusionné depuis la version racine -->

# Profil Stratégique – Florian Maillard
## Synthèse des 12 dimensions IA_Florian
[Résumé des dimensions : technique, organisation, stratégique, spirituelle, intérieure, etc.]
## Événements structurants
- 🔻 Septembre 2024 : burnout, surdose Lexomil, prise en charge
- 🔆 Avril–mai 2025 : éveil spirituel, appel du veilleur, retour sacramentel
## Axes actuels
- Suivi TCC psychiatrique structuré
- Projet de carnet de veilleur
- Réancrage spirituel à travers l’Eucharistie