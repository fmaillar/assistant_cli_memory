# 🔁 Routine quotidienne – Assistant IA Florian

[...]