# IA_Florian_FINAL_MERGE_MAI2025.md

Document de fusion final, consolidant tous les éléments validés, restructurés et normalisés à la date du 22 mai 2025.

> Ce fichier sert de **point de référence** pour toute future reconstruction, synchronisation ou export du système IA_Florian.
