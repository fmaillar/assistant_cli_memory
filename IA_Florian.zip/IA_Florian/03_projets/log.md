# 🔁 Journal des changements

## [Date] – Action / Décision / Blocage
- Action : Description de l'action entreprise.
- Décision : Changement de stratégie ou ajustement de plan.
- Blocage : Raisons des blocages ou défis rencontrés.
