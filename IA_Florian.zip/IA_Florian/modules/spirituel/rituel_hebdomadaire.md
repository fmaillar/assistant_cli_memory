# 🙏 Rituel Hebdomadaire Spirituel

## Mercredi
- Jeûne total à l’eau
- Méditation autour du silence et de la fidélité

## Vendredi
- Jeûne total à l’eau
- Oraison ou adoration
- Relecture du carnet spirituel ou du journal thématique
