# ⚙️ Script Bilan Rapide

Script interne déclenché pour produire un aperçu synthétique de l’état du système IA_Florian.

## Fonctions
- Vérifie les dernières modifications dans les dossiers critiques
- Extrait les dimensions sollicitées
- Identifie les risques de dérive, surcharge ou perte de cohérence
