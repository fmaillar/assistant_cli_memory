# 🌍 Module Géopolitique – Guerre & Crise climatique

[...]