# 🔄 Rappels Périodiques – IA_Florian

## 📅 Quotidien
- Vérifier `éléments_perdus_en_transition.md`
- Réévaluer surcharge ou dérive éventuelle

## 🗓 Hebdomadaire
- Mercredi & vendredi : jeûne complet
- Vendredi : extraction journal `psychologie_sante.md`

## 📆 Mensuel (le 15)
- Relecture complète de `psychologie_sante.md`
- Bilan mensuel auto-généré via Makefile
