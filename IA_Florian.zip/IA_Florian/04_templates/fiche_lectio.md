# 🙏 Template : fiche Lectio Divina

Contient : lectio, meditatio, oratio, contemplatio, engagement personnel