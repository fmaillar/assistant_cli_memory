# ✅ Tâches professionnelles en cours

## 📌 Certification STI
- [ ] Compléter l’analyse de la matrice CCS
- [ ] Préparer le prochain envoi NoBo avec documents justificatifs
- [ ] Vérification des identifiants dans les fichiers Excel

## 🛠 Automatisations envisagées
- [ ] Générer les tableaux d’exigences avec script Pandoc
- [ ] Ajouter des tests de cohérence sur les colonnes Excel
