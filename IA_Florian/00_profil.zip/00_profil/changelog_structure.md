# Changelog de la structure IA_Florian

Ce fichier trace les évolutions de structure, renommages ou déplacements de fichiers dans le système IA_Florian.

## Historique

- 2025-05-22 : Création du changelog_structure.md
- 2025-05-22 : Normalisation du dossier `05_cas_concrets/`
- 2025-05-22 : Déplacement de `registre_detections_sensibles.md` vers `02_vie_interieure/`
