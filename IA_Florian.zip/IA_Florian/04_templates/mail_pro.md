# 📬 Template : mail professionnel

Prompt : [...]