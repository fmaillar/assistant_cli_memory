<!-- 🟡 Contenu fusionné depuis la version racine -->

# 🎯 Intentions & désirs en cours – Florian
## 🌿 Intérieurs
- Me maintenir aligné malgré les contraintes externes
- Prendre soin de l’unité corps-esprit
## 🙏 Spirituels
- Approfondir l’appel reçu comme veilleur
- Rester fidèle aux intuitions de la Semaine Sainte
## 🧠 Cognitifs
- Mieux exploiter l’archive des conversations
- Maintenir une pratique de réflexion régulière sur les fichiers

<!-- 🟡 Contenu fusionné depuis ./ doublon -->

[...]