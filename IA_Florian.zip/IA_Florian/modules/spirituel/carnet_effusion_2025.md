# 🔥 Carnet de préparation à l’effusion de l’Esprit Saint – 2025

[...]