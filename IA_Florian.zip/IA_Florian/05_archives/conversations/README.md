# 🗃 Archive – Conversations ChatGPT

Ce dossier contient les exports `.json` des conversations complètes de l'utilisateur avec ChatGPT.

## 🔎 Utilisation
- Source de vérité pour l’extraction d’artefacts (prière, stratégie, outils)
- Alimentation du système `IA_Florian` via modules d’analyse
- Base pour réinjection contextuelle automatisée

## 📂 Contenu
- `conversations_2025-05-15.json` : export complet de 937 sessions jusqu’au 15 mai 2025

